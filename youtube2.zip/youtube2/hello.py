from __future__ import unicode_literals
import youtube_dl
import os


from lxml import etree
import urllib




def main(args):
    url = args

   # url=url[:-1]
    urlid=url[-11:]



    youtube = etree.HTML(urllib.urlopen(url).read())
    video_title = youtube.xpath("//span[@id='eow-title']/@title")
    title=''.join(video_title)
    print('Video Name:' + title)

    audiofilename= title+'-'+urlid+'.flac'

    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
        'key': 'FFmpegExtractAudio',
        'preferredcodec': 'flac',
        'preferredquality': '192',
        }],
    }
    with youtube_dl.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])




    cmd = 'curl -X POST -u "apikey:lItMN-apu4kmeSQdWV5_uA1CkA-n27ZRzFEl_bKzmO6v" --header "Content-Type: audio/flac" --data-binary @"'+audiofilename+'" "https://stream.watsonplatform.net/speech-to-text/api/v1/recognize"'
    mystring = str(os.system(cmd))
    print (mystring)
    return mystring


print(main("https://www.youtube.com/watch?v=Uhc9qeUtiZE"))